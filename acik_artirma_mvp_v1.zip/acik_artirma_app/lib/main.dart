import 'dart:async';
import 'package:flutter/material.dart';

void main() => runApp(const AuctionApp());

class AuctionApp extends StatelessWidget {
  const AuctionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'AçıkArtırma',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B63F6)),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class Auction {
  final String title;
  final String category;
  final int startingPrice;
  int currentBid;
  final int increment;
  Duration remaining;

  Auction({
    required this.title,
    required this.category,
    required this.startingPrice,
    required this.currentBid,
    required this.increment,
    required this.remaining,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  late Auction auction;
  Timer? timer;

  @override
  void initState() {
    super.initState();
    auction = Auction(
      title: 'iPhone 14 Pro Max 256 GB',
      category: 'Elektronik',
      startingPrice: 15000,
      currentBid: 18750,
      increment: 500,
      remaining: const Duration(hours: 12, minutes: 34, seconds: 20),
    );
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        if (auction.remaining.inSeconds > 0) {
          auction.remaining -= const Duration(seconds: 1);
        }
      });
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  String money(int n) => '${n.toString().replaceAllMapped(RegExp(r'(?=(\\d{3})+(?!\\d))'), (m) => '.')} TL';

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _categories(),
      _notifications(),
      _profile(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('AçıkArtırma', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.search))],
      ),
      body: pages[tab],
      floatingActionButton: FloatingActionButton(
        onPressed: _addAuction,
        child: const Icon(Icons.add),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Ana Sayfa'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), label: 'Kategoriler'),
          NavigationDestination(icon: Icon(Icons.notifications_none), selectedIcon: Icon(Icons.notifications), label: 'Bildirimler'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _home() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), color: const Color(0xFF09284A)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('En iyi teklif senin olsun!', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Ürününü yayınla, teklifleri topla.', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 18),
      const Text('Devam Eden Açık Artırma', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Card(
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BidPage(auction: auction))),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(height: 170, width: double.infinity, decoration: BoxDecoration(color: Colors.blueGrey.shade100, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.phone_iphone, size: 90)),
              const SizedBox(height: 12),
              Text(auction.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              Text(auction.category, style: TextStyle(color: Colors.grey.shade600)),
              const SizedBox(height: 8),
              Text(money(auction.currentBid), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF0B8F55))),
              Text('Güncel en yüksek teklif • Artış: ${money(auction.increment)}', style: TextStyle(color: Colors.grey.shade700)),
              const SizedBox(height: 8),
              Text('Kalan: ${auction.remaining.inHours}sa ${(auction.remaining.inMinutes % 60).toString().padLeft(2, '0')}dk ${(auction.remaining.inSeconds % 60).toString().padLeft(2, '0')}sn', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w700)),
            ]),
          ),
        ),
      ),
    ],
  );

  Widget _categories() => ListView(padding: const EdgeInsets.all(16), children: [
    for (final c in ['Elektronik', 'Moda', 'Ev & Yaşam', 'Koleksiyon', 'Otomobil', 'Diğer'])
      Card(child: ListTile(leading: const Icon(Icons.category_outlined), title: Text(c), trailing: const Icon(Icons.chevron_right))),
  ]);

  Widget _notifications() => const Center(child: Text('Bildirimler\n\nYeni teklif geldiğinde burada görünecek.', textAlign: TextAlign.center));

  Widget _profile() => ListView(padding: const EdgeInsets.all(16), children: [
    const CircleAvatar(radius: 38, child: Icon(Icons.person, size: 42)),
    const SizedBox(height: 10),
    const Center(child: Text('Mehmet Üstündağ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
    const SizedBox(height: 20),
    for (final x in ['Profil Bilgileri', 'Tekliflerim', 'Kazandığım Ürünler', 'Satışlarım', 'Yardım & Destek']) Card(child: ListTile(title: Text(x), trailing: const Icon(Icons.chevron_right))),
  ]);

  void _addAuction() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ürün ekleme ekranı bir sonraki sürümde bağlanacak.')));
  }
}

class BidPage extends StatefulWidget {
  final Auction auction;
  const BidPage({super.key, required this.auction});
  @override
  State<BidPage> createState() => _BidPageState();
}

class _BidPageState extends State<BidPage> {
  final controller = TextEditingController();

  String money(int n) => '${n.toString().replaceAllMapped(RegExp(r'(?=(\\d{3})+(?!\\d))'), (m) => '.')} TL';

  void bid() {
    final value = int.tryParse(controller.text.replaceAll('.', '').replaceAll(',', ''));
    if (value == null || value < widget.auction.currentBid + widget.auction.increment) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('En az ${money(widget.auction.currentBid + widget.auction.increment)} teklif vermelisiniz.')));
      return;
    }
    setState(() => widget.auction.currentBid = value);
    controller.clear();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Teklifiniz alındı!')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Ürün Detayı')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(height: 240, decoration: BoxDecoration(color: Colors.blueGrey.shade100, borderRadius: BorderRadius.circular(18)), child: const Icon(Icons.phone_iphone, size: 120)),
      const SizedBox(height: 16),
      Text(widget.auction.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      Text(widget.auction.category),
      const SizedBox(height: 12),
      Text(money(widget.auction.currentBid), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Color(0xFF0B8F55))),
      const Text('Güncel en yüksek teklif'),
      const SizedBox(height: 20),
      TextField(controller: controller, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Teklif tutarı', prefixText: '₺ ', border: OutlineInputBorder())),
      const SizedBox(height: 10),
      Wrap(spacing: 8, children: [for (final x in [500, 1000, 2000]) OutlinedButton(onPressed: () => controller.text = '${widget.auction.currentBid + x}', child: Text('+$x'))]),
      const SizedBox(height: 12),
      FilledButton(onPressed: bid, child: const Padding(padding: EdgeInsets.all(14), child: Text('Teklif Ver'))),
    ]),
  );
}
